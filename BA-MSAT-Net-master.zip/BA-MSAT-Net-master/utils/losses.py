import torch
import torch.nn as nn
import torch.nn.functional as F

class DiceLoss(nn.Module):
    """Multi-class Dice loss."""
    def __init__(self, smooth=1e-5):
        super(DiceLoss, self).__init__()
        self.smooth = smooth

    def forward(self, logits, targets):
        # logits: (B, C, D, H, W) raw scores; targets: (B, D, H, W) long
        num_classes = logits.shape[1]
        probs = F.softmax(logits, dim=1)
        targets_onehot = F.one_hot(targets, num_classes=num_classes).permute(0, 4, 1, 2, 3).float()
        intersection = (probs * targets_onehot).sum(dim=(2,3,4))
        cardinality = probs.sum(dim=(2,3,4)) + targets_onehot.sum(dim=(2,3,4))
        dice = (2.0 * intersection + self.smooth) / (cardinality + self.smooth)
        return 1 - dice.mean()

class BoundaryLoss(nn.Module):
    """Binary cross-entropy for boundary map."""
    def __init__(self):
        super(BoundaryLoss, self).__init__()
        self.bce = nn.BCEWithLogitsLoss()

    def forward(self, boundary_logits, boundary_gt):
        # boundary_gt: (B, 1, D, H, W) binary
        return self.bce(boundary_logits, boundary_gt)

class CompoundLoss(nn.Module):
    """
    Compound loss combining Dice loss, Cross-Entropy, and Boundary loss.
    L_total = λ_sem * L_semantic + λ_bnd * L_boundary
    """
    def __init__(self, lambda_sem=1.0, lambda_bnd=0.1):
        super(CompoundLoss, self).__init__()
        self.dice = DiceLoss()
        self.ce = nn.CrossEntropyLoss()
        self.boundary = BoundaryLoss()
        self.lambda_sem = lambda_sem
        self.lambda_bnd = lambda_bnd

    def forward(self, seg_logits, boundary_logits, targets, boundary_gt):
        # semantic loss (Dice + CE)
        dice_loss = self.dice(seg_logits, targets)
        ce_loss = self.ce(seg_logits, targets)
        sem_loss = dice_loss + ce_loss

        # boundary loss
        bnd_loss = self.boundary(boundary_logits, boundary_gt)

        return self.lambda_sem * sem_loss + self.lambda_bnd * bnd_loss, sem_loss, bnd_loss