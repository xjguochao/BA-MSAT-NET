import torch
import torch.nn as nn
import torch.nn.functional as F
from .modules import ResidualBlock, MultiScaleSpatialModule, TransformerSelfAttention, AttentionGate, BoundaryPredictionBranch

class BA_MSAT_Net(nn.Module):
    """
    BA-MSAT-Net: Boundary-Aware Multi-Scale Attention Transformer Network
    for segmentation of tooth crowns, roots, maxilla, and mandible.
    """
    def __init__(self, in_channels=1, num_classes=4, base_filters=32, num_heads=8, dropout=0.1):
        super(BA_MSAT_Net, self).__init__()
        # Encoder
        self.encoder1 = nn.Sequential(
            ResidualBlock(in_channels, base_filters),
            ResidualBlock(base_filters, base_filters)
        )
        self.down1 = nn.Conv3d(base_filters, base_filters*2, kernel_size=2, stride=2)
        self.encoder2 = nn.Sequential(
            ResidualBlock(base_filters*2, base_filters*2),
            ResidualBlock(base_filters*2, base_filters*2)
        )
        self.down2 = nn.Conv3d(base_filters*2, base_filters*4, kernel_size=2, stride=2)
        self.encoder3 = nn.Sequential(
            ResidualBlock(base_filters*4, base_filters*4),
            ResidualBlock(base_filters*4, base_filters*4)
        )
        self.down3 = nn.Conv3d(base_filters*4, base_filters*8, kernel_size=2, stride=2)
        self.encoder4 = nn.Sequential(
            ResidualBlock(base_filters*8, base_filters*8),
            ResidualBlock(base_filters*8, base_filters*8)
        )
        self.down4 = nn.Conv3d(base_filters*8, base_filters*16, kernel_size=2, stride=2)
        self.encoder5 = nn.Sequential(
            ResidualBlock(base_filters*16, base_filters*16),
            ResidualBlock(base_filters*16, base_filters*16)
        )

        # Multi-scale module after encoder (optional to insert at various levels)
        self.multi_scale = MultiScaleSpatialModule(base_filters*16, base_filters*16)

        # Transformer bottleneck
        self.transformer = TransformerSelfAttention(dim=base_filters*16, num_heads=num_heads, dropout=dropout)

        # Decoder (with attention gates)
        self.up4 = nn.ConvTranspose3d(base_filters*16, base_filters*8, kernel_size=2, stride=2)
        self.attention_gate4 = AttentionGate(base_filters*8, base_filters*8, base_filters*4)
        self.decoder4 = nn.Sequential(
            ResidualBlock(base_filters*8, base_filters*8),
            ResidualBlock(base_filters*8, base_filters*8)
        )

        self.up3 = nn.ConvTranspose3d(base_filters*8, base_filters*4, kernel_size=2, stride=2)
        self.attention_gate3 = AttentionGate(base_filters*4, base_filters*4, base_filters*2)
        self.decoder3 = nn.Sequential(
            ResidualBlock(base_filters*4, base_filters*4),
            ResidualBlock(base_filters*4, base_filters*4)
        )

        self.up2 = nn.ConvTranspose3d(base_filters*4, base_filters*2, kernel_size=2, stride=2)
        self.attention_gate2 = AttentionGate(base_filters*2, base_filters*2, base_filters)
        self.decoder2 = nn.Sequential(
            ResidualBlock(base_filters*2, base_filters*2),
            ResidualBlock(base_filters*2, base_filters*2)
        )

        self.up1 = nn.ConvTranspose3d(base_filters*2, base_filters, kernel_size=2, stride=2)
        self.attention_gate1 = AttentionGate(base_filters, base_filters, base_filters//2)
        self.decoder1 = nn.Sequential(
            ResidualBlock(base_filters, base_filters),
            ResidualBlock(base_filters, base_filters)
        )

        # Final segmentation head
        self.final_conv = nn.Conv3d(base_filters, num_classes, kernel_size=1)

        # Boundary prediction branch (attached to decoder features)
        self.boundary_branch = BoundaryPredictionBranch(base_filters, 1)  # binary boundary

    def forward(self, x):
        # Encoding path with skip connections
        enc1 = self.encoder1(x)          # (B, f, D, H, W)
        down1 = self.down1(enc1)
        enc2 = self.encoder2(down1)
        down2 = self.down2(enc2)
        enc3 = self.encoder3(down2)
        down3 = self.down3(enc3)
        enc4 = self.encoder4(down3)
        down4 = self.down4(enc4)
        enc5 = self.encoder5(down4)

        # Multi-scale and transformer at bottleneck
        ms = self.multi_scale(enc5)
        trans = self.transformer(ms)

        # Decoding path with attention gates
        up4 = self.up4(trans)
        attn4 = self.attention_gate4(enc4, up4)
        dec4 = self.decoder4(up4 + attn4)  # residual connection

        up3 = self.up3(dec4)
        attn3 = self.attention_gate3(enc3, up3)
        dec3 = self.decoder3(up3 + attn3)

        up2 = self.up2(dec3)
        attn2 = self.attention_gate2(enc2, up2)
        dec2 = self.decoder2(up2 + attn2)

        up1 = self.up1(dec2)
        attn1 = self.attention_gate1(enc1, up1)
        dec1 = self.decoder1(up1 + attn1)

        # Final segmentation logits
        seg_logits = self.final_conv(dec1)

        # Boundary prediction (from decoder1 features)
        boundary_logits = self.boundary_branch(dec1)

        return seg_logits, boundary_logits