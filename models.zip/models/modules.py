import torch
import torch.nn as nn
import torch.nn.functional as F

class ResidualBlock(nn.Module):
    """Residual block with two 3D conv layers and a skip connection."""
    def __init__(self, in_channels, out_channels, stride=1):
        super(ResidualBlock, self).__init__()
        self.conv1 = nn.Conv3d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm3d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv3d(out_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm3d(out_channels)
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv3d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm3d(out_channels)
            )
        else:
            self.shortcut = nn.Identity()

    def forward(self, x):
        identity = self.shortcut(x)
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)
        out += identity
        out = self.relu(out)
        return out

class MultiScaleSpatialModule(nn.Module):
    """Multi-scale contextual aggregation using parallel dilated convolutions."""
    def __init__(self, in_channels, out_channels):
        super(MultiScaleSpatialModule, self).__init__()
        self.conv1 = nn.Conv3d(in_channels, out_channels, kernel_size=1)
        self.conv2 = nn.Conv3d(in_channels, out_channels, kernel_size=3, padding=1, dilation=1)
        self.conv3 = nn.Conv3d(in_channels, out_channels, kernel_size=3, padding=2, dilation=2)
        self.conv4 = nn.Conv3d(in_channels, out_channels, kernel_size=3, padding=3, dilation=3)
        self.fusion = nn.Conv3d(out_channels * 4, out_channels, kernel_size=1)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x1 = self.relu(self.conv1(x))
        x2 = self.relu(self.conv2(x))
        x3 = self.relu(self.conv3(x))
        x4 = self.relu(self.conv4(x))
        out = torch.cat([x1, x2, x3, x4], dim=1)
        out = self.relu(self.fusion(out))
        return out

class TransformerSelfAttention(nn.Module):
    """Transformer encoder block at bottleneck for long-range dependencies."""
    def __init__(self, dim, num_heads=8, mlp_ratio=4, dropout=0.1):
        super(TransformerSelfAttention, self).__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, num_heads, dropout=dropout)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, dim * mlp_ratio),
            nn.GELU(),
            nn.Linear(dim * mlp_ratio, dim),
            nn.Dropout(dropout)
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        # x: (B, C, D, H, W)
        B, C, D, H, W = x.shape
        # reshape to (sequence_len, batch, channel)
        x_flat = x.flatten(2).permute(2, 0, 1)  # (D*H*W, B, C)
        # self-attention
        attn_out, _ = self.attn(self.norm1(x_flat), self.norm1(x_flat), self.norm1(x_flat))
        x_flat = x_flat + self.dropout(attn_out)
        x_flat = x_flat + self.mlp(self.norm2(x_flat))
        # back to (B, C, D, H, W)
        x_out = x_flat.permute(1, 2, 0).view(B, C, D, H, W)
        return x_out

class AttentionGate(nn.Module):
    """Attention gate for skip connections."""
    def __init__(self, in_channels, gating_channels, inter_channels):
        super(AttentionGate, self).__init__()
        self.W_x = nn.Conv3d(in_channels, inter_channels, kernel_size=1)
        self.W_g = nn.Conv3d(gating_channels, inter_channels, kernel_size=1)
        self.psi = nn.Conv3d(inter_channels, 1, kernel_size=1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, g):
        # x: skip feature, g: decoder feature
        x_conv = self.W_x(x)
        g_conv = self.W_g(g)
        attn = self.psi(torch.relu(x_conv + g_conv))
        attn = self.sigmoid(attn)
        return x * attn

class BoundaryPredictionBranch(nn.Module):
    """Auxiliary branch for boundary prediction using dilated convolutions."""
    def __init__(self, in_channels, num_classes):
        super(BoundaryPredictionBranch, self).__init__()
        self.conv1 = nn.Conv3d(in_channels, 64, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm3d(64)
        self.conv2 = nn.Conv3d(64, 64, kernel_size=3, padding=2, dilation=2)
        self.bn2 = nn.BatchNorm3d(64)
        self.conv3 = nn.Conv3d(64, num_classes, kernel_size=1)

    def forward(self, x):
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        out = self.conv3(x)
        return out