import csv
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
with (root / "figure_manifest.csv").open(encoding="utf-8-sig", newline="") as handle:
    rows = list(csv.DictReader(handle))
failures = []
for row in rows:
    key = f"{row['figure_id']} {row['panel']}"
    status = row["release_status"]
    if status == "no_numeric_data":
        continue
    if status != "ready":
        failures.append(f"{key}: status is {status}")
        continue
    values = [x.strip() for x in row["planned_processed_data"].split(";")]
    for value in values:
        if not value or not (root / value).is_file():
            failures.append(f"{key}: missing {value}")
if failures:
    print("NOT READY FOR RELEASE")
    print("\n".join(failures))
    sys.exit(1)
print("Manifest paths and statuses pass. Verify contents, de-identification and figure recreation separately.")
