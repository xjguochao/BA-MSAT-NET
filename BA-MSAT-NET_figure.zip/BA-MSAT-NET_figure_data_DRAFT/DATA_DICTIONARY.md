# Data dictionary for the planned processed files

**This document defines requested data schemas. The CSV files under `templates/` contain headers only.** Values must come from the actual experiments.

## `fig02_epoch_metrics.csv`

One row per model, run, split, metric and epoch. `precision` and `recall` are proportions from 0 to 1. State whether metrics are micro, macro or class specific, how classes are combined, and which cases were evaluated at each epoch. The existing TIFF shows epochs through 100; verify the actual run length and retain the training logs.

Required fields: `model`, `run_id`, `checkpoint_or_log`, `epoch`, `split`, `averaging`, `class_or_region`, `precision`, `recall`.

## `fig03_cases.csv` and `fig07_roi_cases.csv`

One row per displayed case, plane, region and model. Use a nonidentifying public `case_id`. The row must identify the image, reference mask, predicted mask, any boundary-error or FP/FN map, physical voxel spacing, slice index or world coordinate, crop bounds, orientation, intensity window and rendering config. Preserve exact model names and checkpoints.

## `fig04_activation_manifest.csv`

One row per model heatmap. Record case, scan, model, checkpoint, target network layer, activation tensor path, projection/upsampling, normalization, color scale, slice, crop and rendering config. An exported color TIFF alone is insufficient to recreate the heatmap.

## `fig05_reconstruction_manifest.csv`

One row per displayed view. Record case, source mask or surface mesh, anatomical class, physical spacing, meshing parameters, camera position/orientation, opacity, color and rendering software/version. Panels A–C and D–F should be linked to their exact source cases.

## `fig06_patient_metrics.csv` and `fig06_plot_summary.csv`

Patient-level rows should contain the anonymized case ID, data split, ablation variant, anatomical region, crown DSC, root DSC, boundary F1 and HD95 in millimeters. Use blanks where a metric is not defined; do not insert zero. Plot summaries must state numerator/denominator, mean, 95% CI limits, statistical test, correction method, exact p-value and parameter count. Specify whether error bars represent case-level intervals or repeated-run intervals. Define HD versus HD95 consistently with the manuscript and source calculations.

## Privacy and provenance

Never include original clinical filenames, accession numbers, names or dates in public CSVs. De-identification, NIfTI metadata, visible annotations and publication permission require independent review before any image or mask release. Record source code commit, data processing version and figure script for each panel.
