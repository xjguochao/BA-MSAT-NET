# BA-MSAT-Net figure data package

**Status: DRAFT — not ready for public release or an editor-compliance claim.**

This inventory is based on `2026-10-07 full_manuscript.docx`, `10-07 Tables.docx`, and the seven submitted TIFF files (`Fig 1.tif`–`Fig 7.tif`). The final manuscript identifies seven main figures. It lists supplementary Tables S1 and S2, but no supplementary figures. The figure TIFF files are rendered outputs and are not substitutes for the data used to make them.

`figure_manifest.csv` maps each visible figure panel to the processed file that must be supplied. Its `release_status` column currently records missing material and unresolved discrepancies. The planned paths are **filenames to create**, not assertions that those files exist. No clinical images, original filename mapping, patient-level results, predictions, heatmaps, or fabricated measurements are included in this draft.

## Figure-to-data relationship

| Figure | Required data or source | Current state |
| --- | --- | --- |
| Fig 1 | Editable architecture drawing; no numerical processed data | Rendered TIFF found; editable source not found; patch size requires reconciliation |
| Fig 2 | Epoch-by-epoch precision and recall for the three models | Metric logs not found |
| Fig 3 | Approved anonymized CBCT volume(s), reference mask(s), model predictions, boundary-error calculation and exact slice/crop settings | Case and prediction mapping not found; model label conflict |
| Fig 4 | Underlying CBCT slice and activation arrays for each model, including layer and color normalization | Activation arrays not found |
| Fig 5 | Approved segmentation masks or meshes, class colors and six camera views | Source masks/meshes and case mapping not found |
| Fig 6A–C | Actual ablation results by case, variant and region; plot summaries, 95% CIs, significance calculations and parameter counts | Table 9 has partial reported summaries; figure/table values conflict; patient-level data not found |
| Fig 7a–c | Approved CBCT, reference and prediction masks for each ROI, plus FP/FN maps and rendering settings | Case and prediction mapping not found; caption calls qualitative panels quantitative |

## Files in this draft

- `figure_manifest.csv`: panel-level crosswalk and current release status.
- `DATA_DICTIONARY.md`: schemas and definitions for the needed processed files.
- `templates/`: headers only, to be populated from authentic experiment output.
- `AUDIT.md`: inconsistencies and release checks to resolve.
- `METHODS_AND_SOURCES.md`: relevant journal, Zenodo and medical-imaging documentation used to design the package.
- `audit/table9_as_reported_NOT_figure_source.csv`: a transcription of reported Table 9 summary values for reconciliation only.
- `validate_release.py`: checks whether each panel has been marked ready and its specified files exist.

## Completing the release

Populate the planned files from experiment logs, per-case evaluations and approved anonymized image/segmentation sources. For each panel, record anonymized case IDs, experimental split, model and checkpoint, metric definition, units, preprocessing, aggregation, uncertainty method, software version, plot script and rendered output. Correct the conflicts in `AUDIT.md`, then update the manifest to actual relative paths and change statuses to `ready` or `no_numeric_data` as appropriate. Run `python validate_release.py` and inspect every regenerated panel against the final manuscript before uploading to GitHub or Zenodo.

The original-to-renamed image mapping found elsewhere on the local computer is **not** included. It may reveal original identifiers and does not establish that the NIfTI headers or images are approved for public release.
