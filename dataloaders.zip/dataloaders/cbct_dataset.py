import os
import numpy as np
import nibabel as nib
import torch
from torch.utils.data import Dataset
import random

class CBCTSegDataset(Dataset):
    """
    Dataset for loading CBCT volumes and multi-class segmentation masks.
    Labels: 0=background, 1=tooth crown, 2=tooth root, 3=maxilla, 4=mandible.
    """
    def __init__(self, data_dir, label_dir, file_list=None, patch_size=(160,160,160),
                 transform=None, split='train'):
        self.data_dir = data_dir
        self.label_dir = label_dir
        self.patch_size = patch_size
        self.transform = transform
        self.split = split

        if file_list is not None:
            with open(file_list, 'r') as f:
                self.file_names = [line.strip() for line in f.readlines()]
        else:
            # assume filenames are the same in both directories, just with different extensions
            self.file_names = [f for f in os.listdir(data_dir) if f.endswith('.nii.gz')]

        print(f"Total {len(self.file_names)} samples for {split}")

    def __len__(self):
        return len(self.file_names)

    def __getitem__(self, idx):
        fname = self.file_names[idx]
        img_path = os.path.join(self.data_dir, fname)
        label_path = os.path.join(self.label_dir, fname)

        # Load volume and label
        img = nib.load(img_path).get_fdata().astype(np.float32)
        label = nib.load(label_path).get_fdata().astype(np.uint8)

        # Resample to 0.4mm isotropic (simplified – assume already isotropic for this example)
        # Here we just pad/crop to patch_size for training
        if self.split == 'train':
            # Random crop
            img, label = self._random_crop(img, label)
        else:
            # Center crop for validation/test
            img, label = self._center_crop(img, label)

        # Normalize image to [0,1] based on percentile
        img = self._normalize(img)

        # Convert to tensors
        img_tensor = torch.from_numpy(img).unsqueeze(0).float()  # (1, D, H, W)
        label_tensor = torch.from_numpy(label).long()            # (D, H, W)

        if self.transform:
            img_tensor, label_tensor = self.transform(img_tensor, label_tensor)

        return img_tensor, label_tensor

    def _random_crop(self, img, label):
        D, H, W = img.shape
        pd, ph, pw = self.patch_size
        if D < pd or H < ph or W < pw:
            # pad if smaller than patch
            pad_d = max(pd - D, 0)
            pad_h = max(ph - H, 0)
            pad_w = max(pw - W, 0)
            img = np.pad(img, ((0, pad_d), (0, pad_h), (0, pad_w)), mode='constant')
            label = np.pad(label, ((0, pad_d), (0, pad_h), (0, pad_w)), mode='constant')
            D, H, W = img.shape

        # random top-left corner
        start_d = random.randint(0, D - pd)
        start_h = random.randint(0, H - ph)
        start_w = random.randint(0, W - pw)

        img_crop = img[start_d:start_d+pd, start_h:start_h+ph, start_w:start_w+pw]
        label_crop = label[start_d:start_d+pd, start_h:start_h+ph, start_w:start_w+pw]
        return img_crop, label_crop

    def _center_crop(self, img, label):
        D, H, W = img.shape
        pd, ph, pw = self.patch_size
        if D < pd or H < ph or W < pw:
            pad_d = max(pd - D, 0)
            pad_h = max(ph - H, 0)
            pad_w = max(pw - W, 0)
            img = np.pad(img, ((0, pad_d), (0, pad_h), (0, pad_w)), mode='constant')
            label = np.pad(label, ((0, pad_d), (0, pad_h), (0, pad_w)), mode='constant')
            D, H, W = img.shape
        start_d = (D - pd) // 2
        start_h = (H - ph) // 2
        start_w = (W - pw) // 2
        img_crop = img[start_d:start_d+pd, start_h:start_h+ph, start_w:start_w+pw]
        label_crop = label[start_d:start_d+pd, start_h:start_h+ph, start_w:start_w+pw]
        return img_crop, label_crop

    def _normalize(self, img):
        # Clip to [500, 2500] as per paper, then scale to [0,1]
        img = np.clip(img, 500, 2500)
        img = (img - 500) / (2500 - 500)
        return img